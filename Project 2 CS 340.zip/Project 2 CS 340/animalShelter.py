# Create this method to implement the C in CRUD
    def create(self,data);
    if data is not None:
        insert = self.database.animals.insert(data) # data should be dictionary
        
        else:
            raise Exception("Nothing to save, data parameter is empty")
            
# Create this method to implement the R in CRUD 
